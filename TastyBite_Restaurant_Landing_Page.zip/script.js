const toggle=document.querySelector(".menu-toggle"),nav=document.querySelector(".nav"),toast=document.querySelector(".toast");
toggle?.addEventListener("click",()=>{const open=nav.classList.toggle("open");toggle.setAttribute("aria-expanded",open)});
document.querySelectorAll(".nav a").forEach(a=>a.addEventListener("click",()=>nav.classList.remove("open")));
document.querySelectorAll(".cart-btn").forEach(btn=>btn.addEventListener("click",()=>{toast.textContent="Added to your order ✓";toast.classList.add("show");setTimeout(()=>toast.classList.remove("show"),1800)}));
